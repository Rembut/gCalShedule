app.method(
	path, 
	handler
)
