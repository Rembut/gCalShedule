const mocha = require('mocha');
const chai = require('chai');

const expect = chai.expect;

describe('Reverse String Test', () => {
    it('Checks if the strings is reversed', () => {
        // Code 
    });
});